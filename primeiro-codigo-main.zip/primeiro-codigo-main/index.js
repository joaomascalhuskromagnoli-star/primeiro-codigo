document.getElementById("texto").innerHTML="Meu primeiro texto <b>JS</b>!";
console.log("Oi isso é um um console.log");